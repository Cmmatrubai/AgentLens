# AgentLens · Quiet Lab

**Prototype 01 — an interactive desktop design study.**

A calm task library leads into a two-attempt comparison. The outcome comes first; the decisive check and its evidence are one click away. This prototype explores the comparison-first product direction with fictional examples.

![Workspace](qa/workspace-1440.jpg)

## Try it

```sh
pnpm install
pnpm desktop
```

`pnpm desktop` builds the interface and opens it in Electron. It loads local bundled files and does not need the development server. The first Electron launch may download its binary through the installed package.

For browser development:

```sh
pnpm dev
```

Open **http://127.0.0.1:5177**. For the built browser preview, run `pnpm build` followed by `pnpm preview` (stop the development server first, because both use 5177). The coordinator's review instance is temporarily serving the built version at **http://127.0.0.1:5178**.

## A useful two-minute tour

1. Choose **Review comparison**. Model A passes three checks; Model B is faster but misses an expired-session case.
2. Select the difference or a model's individual check segment. Switch between result, illustrative patch, and context in the evidence drawer.
3. Open **Checks** or **Execution**, and compare the shared setup.
4. Use **Save as case**. Rename the challenge, choose its success conditions, and reopen it from **Saved cases**. User-created cases can be removed and immediately restored with **Undo**.
5. Press **⌘K** (Ctrl+K also works) to find another task or an action. The oversized-event example demonstrates missing evidence; the process-cleanup example shows the candidate doing better.
6. Use the play button to replay the sample evaluation sequence. It can be canceled. Preferences offer compact spacing and reduced interface motion.

## What is implemented

- Native Electron window with local assets, React and TypeScript.
- Motion layout transitions, animated tabs, drawer/dialog entrance and exit, task filtering and replay progress.
- Radix dialog focus management and tooltips, cmdk keyboard search, Lucide icons, bundled Inter and Geist Mono.
- Three coherent example tasks; same-task comparison, acceptance checks, model-specific evidence selection, illustrative patch and execution views.
- Search, status/repository filters, hash navigation with browser back/forward, accessible collapsed navigation.
- Case form validation, selected-condition persistence, saved-case details, removal/undo, and persisted preferences.

## Scope

**All repositories, model labels, timings, results, revisions and code snippets are fictional fixtures.** No model is called, no command is executed by the replay, and no real repository is read or changed. A saved case opens its original sample comparison; it does not run an evaluation using edited conditions.

Cases and preferences use local storage for this preview. Browser and Electron previews keep separate local data. This is a runnable design prototype, not the AgentLens production UI, a packaged/signed release, or a measured model benchmark.

The source is isolated on `codex/agentlens-desktop-prototype-v1` in the ChatGPT project mirror's linked worktree. The canonical AgentLens repository and the existing Flight Console and `design-prototypes/` work remain separate.

## Design references and validation

See [DESIGN.md](DESIGN.md) for primary references and library choices, and [qa/REPORT.md](qa/REPORT.md) for observed checks and limitations.
