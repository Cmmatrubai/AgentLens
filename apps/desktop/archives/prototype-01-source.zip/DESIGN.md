# AgentLens desktop prototype 01 — Quiet Lab

A disposable prototype authorized by the user's September 6 request. Mock data only. No production or protected prototype changes.

## Experience

A quiet desktop workspace that moves from saved tasks to a two-attempt comparison, then to exact illustrative evidence. Strong hierarchy, subdued navigation, one main next action, and meaningful motion. No opaque model score or population-level ranking. Each result is scoped to the shown attempts.

## First-pass scope

- Desktop window chrome, collapsible workspace sidebar, task search, status filters, and repository filters.
- Three distinct saved task examples and comparison detail, including passing, failing and incomplete evidence.
- Comparison summary, acceptance-check matrix, important differences, and expandable execution context.
- Evidence drawer with check output, illustrative patch and source context.
- Save-as-case form, persisted local evaluation cases, replay simulation with cancellation, and command palette.
- Motion shared-layout navigation and tabs, staggered entry, drawer and dialog transitions, progress feedback, and reduced-motion support.
- All interactions operate on demonstration data; the UI says so. No API keys, agent execution, real repo reads, telemetry upload, provider performance claims or publishing.

## References and libraries

- Linear, March 12 2026 refresh: https://linear.app/now/behind-the-latest-design-refresh — reduce navigation weight and use softer separation.
- Raycast technical design: https://www.raycast.com/blog/a-technical-deep-dive-into-the-new-raycast — keyboard access and action search.
- NN/G progressive disclosure: https://www.nngroup.com/articles/progressive-disclosure/ — advanced evidence on request.
- 21st Animated Sidebar by unlumen: https://21st.dev/@unlumen/components/sidebar-001 — reviewed spring hover/selection and collapsed navigation patterns. The prototype implements a smaller original sidebar for this workflow.
- 21st Command by Origin UI: https://21st.dev/@originui/components/command — reviewed composition of cmdk and a dialog. The prototype uses cmdk and Radix directly with meaningful accessible labels.
- React, Motion, Radix Dialog/Tooltip, cmdk, Lucide React, and locally bundled Inter/Geist Mono fonts.

21st reference retrieval used the two available daily free code lookups. No paid generation, purchase or upgrade was performed. Retrieved reference code is not copied wholesale; design patterns inform original components.

## Validation target

Typecheck and production build; actual browser review at wide and narrow desktop widths if the administrative browser-policy check permits it. Check navigation, keyboard search, dialog focus/escape, comparison change, evidence tabs, case save/validation, replay/cancel, reload persistence and reduced motion. Never claim browser validation from source review or bypass a policy denial.
